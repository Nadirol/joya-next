(() => {
var exports = {};
exports.id = 521;
exports.ids = [521];
exports.modules = {

/***/ 7553:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Plus_Jakarta_Sans_843728', '__Plus_Jakarta_Sans_Fallback_843728'","fontStyle":"normal"},
	"className": "__className_843728"
};


/***/ }),

/***/ 6173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AboutPage),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"pages\\about\\index.tsx","import":"Plus_Jakarta_Sans","arguments":[{"weight":["400","500","600"],"subsets":["latin","vietnamese"]}],"variableName":"plusJakartaSans"}
var target_path_pages_about_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_ = __webpack_require__(7553);
var target_path_pages_about_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_default = /*#__PURE__*/__webpack_require__.n(target_path_pages_about_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_);
// EXTERNAL MODULE: ./public/assets/index.ts + 32 modules
var assets = __webpack_require__(2993);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/about/About.tsx



const About = ({ t  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "about",
        className: "flex gap-6 flex-col items-center text-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-neutral-900 font-semibold text-2xl xl:text-4xl",
                children: t("aboutUs")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: assets/* logoLightLarge */.ch,
                alt: "brand logo",
                className: "w-20 xl:w-[7.5rem] aspect-square"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-neutral-800 font-regular text-base xl:text-xl w-paragraph mx-auto",
                        children: t("aboutParagraph1")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-neutral-800 font-regular text-base xl:text-xl w-paragraph mx-auto",
                        children: t("aboutParagraph2")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-neutral-800 font-regular text-base xl:text-xl w-paragraph mx-auto",
                        children: t("aboutParagraph3")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-neutral-800 font-regular text-base xl:text-xl w-paragraph mx-auto",
                        children: t("aboutParagraph4")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-neutral-800 font-regular text-base xl:text-xl w-paragraph mx-auto",
                        children: t("aboutParagraph5")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-neutral-800 font-regular text-base xl:text-xl w-paragraph mx-auto",
                        children: t("aboutParagraph6")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const about_About = (About);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/about/Catalogue.tsx




const Catalogue = ({ t  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "tours",
        className: "flex gap-5 flex-col items-center text-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-neutral-900 font-semibold text-xl md:text-4xl",
                children: t("toursCatalogue")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-neutral-800 font-regular text-xs md:text-xl",
                children: t("toursCatalogueHeading")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/assets/JOYA_Catalogue_EN.pdf",
                target: "_blank",
                className: "bg-primary-regular hover:bg-primary-dark px-6 py-4 rounded-[30px] text-neutral-100 font-semibold text-base leading-5",
                children: t("downloadCatalogue")
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid gap-3 grid-cols-3 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: assets/* galleryImage1 */.ZB,
                        alt: "gallery image",
                        className: "rounded-xl"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: assets/* galleryImage2 */.Br,
                        alt: "gallery image",
                        className: "rounded-xl"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: assets/* galleryImage3 */.oO,
                        alt: "gallery image",
                        className: "rounded-xl"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: assets/* galleryImage4 */.Dv,
                        alt: "gallery image",
                        className: "rounded-xl"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: assets/* galleryImage5 */.z,
                        alt: "gallery image",
                        className: "rounded-xl"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: assets/* galleryImage6 */.ST,
                        alt: "gallery image",
                        className: "rounded-xl"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const about_Catalogue = (Catalogue);

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: ./components/Header.tsx
var Header = __webpack_require__(9852);
// EXTERNAL MODULE: ./components/Footer.tsx
var Footer = __webpack_require__(932);
;// CONCATENATED MODULE: ./pages/about/index.tsx








function AboutPage() {
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (target_path_pages_about_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_default()).className,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                    t: t
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                    className: "w-container mx-auto flex gap-8 md:gap-12 xl:gap-16 flex-col mb-8 relative mt-12",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(about_About, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(about_Catalogue, {
                            t: t
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
            ]
        })
    });
}
async function getStaticProps({ locale  }) {
    return {
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale, [
                "common"
            ])
        }
    };
}


/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,954,415], () => (__webpack_exec__(6173)));
module.exports = __webpack_exports__;

})();