(() => {
var exports = {};
exports.id = 743;
exports.ids = [743];
exports.modules = {

/***/ 9516:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Plus_Jakarta_Sans_843728', '__Plus_Jakarta_Sans_Fallback_843728'","fontStyle":"normal"},
	"className": "__className_843728"
};


/***/ }),

/***/ 5376:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Tour),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"pages\\tours\\[id]\\index.tsx","import":"Plus_Jakarta_Sans","arguments":[{"weight":["400","500","600"],"subsets":["latin","vietnamese"]}],"variableName":"plusJakartaSans"}
var target_path_pages_tours_id_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_ = __webpack_require__(9516);
var target_path_pages_tours_id_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_default = /*#__PURE__*/__webpack_require__.n(target_path_pages_tours_id_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_);
// EXTERNAL MODULE: ./node_modules/firebase/firestore/dist/index.mjs + 1 modules
var dist = __webpack_require__(8847);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: ./firebaseConfig.js
var firebaseConfig = __webpack_require__(7309);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: ./components/Header.tsx
var Header = __webpack_require__(9852);
// EXTERNAL MODULE: ./components/Footer.tsx
var Footer = __webpack_require__(932);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/main/Grandtours.tsx
var Grandtours = __webpack_require__(2670);
// EXTERNAL MODULE: ./components/main/DayTours.tsx
var DayTours = __webpack_require__(3599);
;// CONCATENATED MODULE: ./pages/tours/[id]/index.tsx
// @ts-nocheck














// run function when clicking outside of ref
const useClickDetector = (ref, func)=>{
    (0,external_react_.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (ref.current && !ref.current.contains(event.target)) {
                func();
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        ref
    ]);
};
function Tour() {
    const router = (0,router_namespaceObject.useRouter)();
    const { id  } = router.query;
    const [tour, setTour] = (0,external_react_.useState)({});
    (0,external_react_.useEffect)(()=>{
        const docRef = (0,dist/* doc */.JU)(firebaseConfig.db, `tours/${id}`);
        const getTour = async ()=>{
            await (0,dist/* getDoc */.QT)(docRef).then((doc)=>{
                setTour({
                    ...doc.data(),
                    id: doc.id
                });
            }).catch((err)=>{
                console.log(err.message);
            });
        };
        getTour();
    }, []);
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    const [firstNameValue, setFirstNameValue] = (0,external_react_.useState)("");
    const [lastNameValue, setLastNameValue] = (0,external_react_.useState)("");
    const [phoneNumberValue, setPhoneNumberValue] = (0,external_react_.useState)("");
    const [emailValue, setEmailValue] = (0,external_react_.useState)("");
    const [messageValue, setMessageValue] = (0,external_react_.useState)("");
    const handleFirstNameChange = (e)=>{
        setFirstNameValue(e.target.value);
    };
    const handleLastNameChange = (e)=>{
        setLastNameValue(e.target.value);
    };
    const handlePhoneNumberChange = (e)=>{
        setPhoneNumberValue(e.target.value);
    };
    const handleEmailChange = (e)=>{
        setEmailValue(e.target.value);
    };
    const handleMessageChange = (e)=>{
        setMessageValue(e.target.value);
    };
    const hideBookForm = ()=>{
        setBookFormVisible(false);
    };
    const [bookFormVisible, setBookFormVisible] = (0,external_react_.useState)(false);
    const bookFormRef = (0,external_react_.useRef)(null);
    useClickDetector(bookFormRef, hideBookForm);
    const [popUpVisible, setPopUpVisible] = (0,external_react_.useState)(false);
    const showPopUp = (e)=>{
        setPopUpVisible(true);
        setTimeout(()=>{
            setPopUpVisible(false);
        }, 2000);
        setBookFormVisible(false);
        setTimeout(()=>{
            setFirstNameValue("");
            setLastNameValue("");
            setPhoneNumberValue("");
            setEmailValue("");
            setMessageValue("");
        }, 200);
    };
    const durationFormat = (num)=>{
        if (num === 1) {
            return num + " " + t("day");
        } else {
            return num + " " + t("days");
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (target_path_pages_tours_id_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_default()).className,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                    t: t
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                    className: "w-container mx-auto mb-8 flex gap-12 flex-col relative",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid gap-8 xl:gap-[8rem] md:grid-cols-details pt-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: tour.image,
                                        width: 600,
                                        height: 400,
                                        alt: "tour image",
                                        className: "mx-auto shadow-card-bold"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "shadow-card-bold rounded-[18px] p-6 flex -md:gap-6 flex-col justify-between",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-4 flex-col",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "text-neutral-900 font-semibold text-3xl",
                                                    children: tour.title
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-disc list-inside flex gap-3 flex-col",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "relative left--6 text-neutral-700 font-semibold text-base",
                                                                children: [
                                                                    t("fullPackage"),
                                                                    ":",
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        className: `ml-1 text-neutral-900 ${tour.price ? "" : "text-sm text-neutral-600"}`,
                                                                        children: tour.price ? tour.price : t("flexible")
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "relative left--6 text-neutral-700 font-semibold text-base",
                                                                children: [
                                                                    t("destinations"),
                                                                    ":",
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        className: `ml-1 text-neutral-900 ${tour.destinations ? "" : "text-sm text-neutral-600"}`,
                                                                        children: tour.destinations ? tour.destinations : t("flexible")
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "relative left--6 text-neutral-700 font-semibold text-base",
                                                                children: [
                                                                    t("duration"),
                                                                    ":",
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        className: `ml-1 text-neutral-900 ${tour.duration ? "" : "text-sm text-neutral-600"}`,
                                                                        children: tour.duration ? durationFormat(tour.duration) : t("flexible")
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-3 flex-col items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "bg-neutral-800 hover:bg-black rounded-[30px] w-full py-3    text-neutral-300 font-semibold text-base",
                                                    onClick: ()=>setBookFormVisible(true),
                                                    children: t("book")
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/contact",
                                                    target: "_blank",
                                                    className: "bg-neutral-300 hover:bg-black rounded-[30px] w-full py-3 text-center   text-neutral-800 hover:text-neutral-300 font-semibold text-base",
                                                    children: t("contactUs")
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Grandtours/* default */.Z, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(DayTours/* default */.Z, {
                            t: t
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `z-40 bottom-1/2 right-1/2 translate-x-1/2 translate-y-1/2 bg-white rounded-[30px] p-12 shadow-card-bold
                    ${bookFormVisible ? "fixed" : "hidden"}`,
                            ref: bookFormRef,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                    name: "frame",
                                    className: "hidden"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                    className: "mx-auto flex flex-col gap-6",
                                    action: "https://formsubmit.co/8015104ab30fce20360f57b9f6f6ee16",
                                    method: "POST",
                                    target: "frame",
                                    onSubmit: (e)=>showPopUp(e),
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "text-neutral-900 font-semibold text-2xl md:text-[2rem] md:leading-10 text-center",
                                            children: `${t("bookTour")} - ${tour.title}`
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-7 -md:flex-col w-full",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex gap-2 flex-col",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "text-neutral-800 font-medium text-base",
                                                            children: t("firstName")
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            name: "First Name",
                                                            placeholder: `${t("firstNamePlaceholder")}`,
                                                            required: true,
                                                            value: firstNameValue,
                                                            onChange: (e)=>handleFirstNameChange(e),
                                                            className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex gap-2 flex-col",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            htmlFor: "",
                                                            className: "text-neutral-800 font-medium text-base",
                                                            children: t("lastName")
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            name: "Last Name",
                                                            placeholder: `${t("lastNamePlaceholder")}`,
                                                            value: lastNameValue,
                                                            onChange: (e)=>handleLastNameChange(e),
                                                            className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-7 -md:flex-col",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex gap-2 flex-col",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            htmlFor: "",
                                                            className: "text-neutral-800 font-medium text-base",
                                                            children: t("phoneNumber")
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            name: "Phone Number",
                                                            placeholder: `${t("phoneNumberPlaceholder")}`,
                                                            value: phoneNumberValue,
                                                            onChange: (e)=>handlePhoneNumberChange(e),
                                                            className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex gap-2 flex-col",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            htmlFor: "",
                                                            className: "text-neutral-800 font-medium text-base",
                                                            children: t("email")
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "email",
                                                            name: "Email",
                                                            placeholder: `${t("emailPlaceholder")}`,
                                                            required: true,
                                                            value: emailValue,
                                                            onChange: (e)=>handleEmailChange(e),
                                                            className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-2 flex-col",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    htmlFor: "message",
                                                    className: "text-neutral-800 font-medium text-base",
                                                    children: t("yourPreference")
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                    id: "message",
                                                    name: "Message",
                                                    placeholder: `${t("yourPreferencePlaceholder")}`,
                                                    rows: 4,
                                                    value: messageValue,
                                                    onChange: (e)=>handleMessageChange(e),
                                                    className: "w-full px-6 py-3 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-2 flex-col",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "text-neutral-800 font-medium text-base",
                                                    children: t("tourType")
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex gap-6",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                    type: "radio",
                                                                    id: "privateType",
                                                                    name: "type",
                                                                    value: `${t("private")}`
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                    htmlFor: "privateType",
                                                                    children: t("private")
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                    type: "radio",
                                                                    id: "privateType",
                                                                    name: "type",
                                                                    value: `${t("public")}`
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                    htmlFor: "privateType",
                                                                    children: t("public")
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "hidden",
                                            name: "Tour Name",
                                            value: tour.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "submit",
                                            value: `${t("send")}`,
                                            className: "bg-primary-extra-light hover:bg-primary-light w-fit cursor-pointer text-neutral-900    font-medium text-xl px-12 py-2.5 rounded-[1.125rem] mx-auto"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "hidden",
                                            name: "_captcha",
                                            value: "false"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "hidden",
                                            name: "_cc",
                                            value: "khanhduycb1510@gmail.com,kristalz248@gmail.com,kristalz931@gmail.com"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `fixed right-1/2 translate-x-1/2 px-8 py-4 rounded-2xl z-30
                    bg-white dark:bg-semi-black transition-all duration-300 pointer-events-none 
                        ${popUpVisible ? "bottom-12 opacity-100" : "opacity-0 bottom-0"} shadow-card-bold`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-neutral-800 font-semibold text-base leading-none z-30",
                        children: "Your Message is sent. Thanks For contacting with us!"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
            ]
        })
    });
}
async function getStaticProps({ locale  }) {
    return {
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale, [
                "common"
            ])
        }
    };
}
const getStaticPaths = async ()=>{
    const querySnapshot = await (0,dist/* getDocs */.PL)(firebaseConfig/* colRef */.G);
    // .then((snapshot) => {
    //     const newData = snapshot.docs.reverse()
    //     .map(doc => ({...doc.data(), id:doc.id }));
    //     return newData
    // })
    // .catch(err => {
    //     console.log(err.message)
    // });
    const paths = [];
    querySnapshot.forEach((doc)=>paths.push({
            params: {
                id: doc.id
            }
        }));
    return {
        paths: paths,
        fallback: "blocking" //indicates the type of fallback
    };
};


/***/ }),

/***/ 6337:
/***/ ((module) => {

"use strict";
module.exports = require("@grpc/grpc-js");

/***/ }),

/***/ 5831:
/***/ ((module) => {

"use strict";
module.exports = require("@grpc/proto-loader");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 3837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,954,647,415,670,599], () => (__webpack_exec__(5376)));
module.exports = __webpack_exports__;

})();