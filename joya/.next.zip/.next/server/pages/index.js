(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 6741:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Plus_Jakarta_Sans_843728', '__Plus_Jakarta_Sans_Fallback_843728'","fontStyle":"normal"},
	"className": "__className_843728"
};


/***/ }),

/***/ 9025:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"pages\\index.tsx","import":"Plus_Jakarta_Sans","arguments":[{"weight":["400","500","600"],"subsets":["latin","vietnamese"]}],"variableName":"plusJakartaSans"}
var target_path_pages_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_ = __webpack_require__(6741);
var target_path_pages_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_default = /*#__PURE__*/__webpack_require__.n(target_path_pages_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_);
// EXTERNAL MODULE: ./public/assets/index.ts + 32 modules
var assets = __webpack_require__(2993);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/main/Banner.tsx



const Banner = ({ t  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " relative md:mb-[6rem]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: assets/* banner */.K_,
                alt: "banner",
                className: "w-full rounded-[30px] object-contain"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white flex gap-2.5 -md:flex-col md:absolute md:bottom-0 md:right-1/2 md:translate-x-1/2 md:translate-y-1/2    px-10 py-6 rounded-3xl md:shadow-card-semibold",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-2.5 flex-col items-center text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: assets/* holdingHandsIcon */.gX,
                                alt: "holding hands icon",
                                className: "w-[2.25rem] xl:w-[3.125rem] aspect-square"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-neutral-900 font-medium text-sm xl:text-xl xl:leading-[25px]",
                                children: t("valueTitle1")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-neutral-900 font-regular text-[0.625rem] w-[210px] xl:text-xs xl:w-[315px]",
                                children: t("valueParagraph1")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-2.5 flex-col items-center text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: assets/* victoryFingersIcon */.ZW,
                                alt: "holding hands icon",
                                className: "w-[2.25rem] xl:w-[3.125rem] aspect-square"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-neutral-900 font-medium text-sm xl:text-xl xl:leading-[25px]",
                                children: t("valueTitle2")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-neutral-900 font-regular text-[0.625rem] w-[210px] xl:text-xs xl:w-[315px]",
                                children: t("valueParagraph2")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-2.5 flex-col items-center text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: assets/* checkIcon */.eQ,
                                alt: "holding hands icon",
                                className: "w-[2.25rem] xl:w-[3.125rem] aspect-square"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-neutral-900 font-medium text-sm xl:text-xl xl:leading-[25px]",
                                children: t("valueTitle3")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-neutral-900 font-regular text-[0.625rem] w-[210px] xl:text-xs xl:w-[315px]",
                                children: t("valueParagraph3")
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const main_Banner = (Banner);

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: ./components/Header.tsx
var Header = __webpack_require__(9852);
// EXTERNAL MODULE: ./components/Footer.tsx
var Footer = __webpack_require__(932);
;// CONCATENATED MODULE: ./components/main/Categories.tsx



const Categories = ({ t  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-primary-extra-light rounded-[30px] p-8 xl:px-[6.375rem] py-7 flex flex-col gap-[2rem]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-4 flex-col text-center items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-neutral-800 font-semibold text-xl md:text-4xl",
                        children: t("categoryHeading1")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-neutral-800 font-normal text-xs md:text-lg w-4/5",
                        children: t("categoryHeading2")
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-4 flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid gap-9 md:grid-cols-category-row-1",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col justify-between p-[18px] rounded-2xl shadow-card bg-white min-h-[263px]",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: assets/* categoriesImage1 */.Bn,
                                                alt: "preview image",
                                                className: "mb-2 w-full mx-auto rounded-xl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-neutral-900 font-medium text-base",
                                                children: t("grandTour")
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-neutral-800 font-normal text-xs",
                                                children: t("grandTourDescription")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "mb-1 ml-auto text-neutral-900 font-medium text-xl",
                                        children: t("explore")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col justify-between p-[18px] rounded-2xl shadow-card bg-white min-h-[263px]",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: assets/* categoriesImage2 */.wT,
                                                alt: "preview image",
                                                className: "mb-2 w-full mx-auto rounded-xl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-neutral-900 font-medium text-base",
                                                children: t("dayTour")
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-neutral-800 font-normal text-xs",
                                                children: t("dayTourDescription")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "mb-1 ml-auto text-neutral-900 font-medium text-xl",
                                        children: t("explore")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid gap-9 md:grid-cols-category-row-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col justify-between p-[18px] rounded-2xl shadow-card bg-white min-h-[263px]",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: assets/* categoriesImage3 */.M1,
                                                alt: "preview image",
                                                className: "mb-2 w-full mx-auto rounded-xl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-neutral-900 font-medium text-base",
                                                children: t("themeTour")
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-neutral-800 font-normal text-xs",
                                                children: t("themeTourDescription")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "mb-1 ml-auto text-neutral-900 font-medium text-xl",
                                        children: t("explore")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col justify-between p-[18px] rounded-2xl shadow-card bg-white min-h-[263px]",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: assets/* categoriesImage4 */.E8,
                                                alt: "preview image",
                                                className: "mb-2 w-full mx-auto rounded-xl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-neutral-900 font-medium text-base",
                                                children: t("privateTour")
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-neutral-800 font-normal text-xs",
                                                children: t("privateTourDescription")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "mb-1 ml-auto text-neutral-900 font-medium text-xl",
                                        children: t("explore")
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const main_Categories = (Categories);

// EXTERNAL MODULE: ./components/main/Grandtours.tsx
var Grandtours = __webpack_require__(2670);
// EXTERNAL MODULE: ./components/main/DayTours.tsx
var DayTours = __webpack_require__(3599);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/main/CustomTours.tsx
"use client";

// @ts-nocheck



const CustomTours = ({ t  })=>{
    const [idealTourDurationValue, setIdealTourDurationValue] = (0,external_react_.useState)("");
    const [yourBudgetValue, setYourBudgetValue] = (0,external_react_.useState)("");
    const [phoneNumberValue, setPhoneNumberValue] = (0,external_react_.useState)("");
    const [emailValue, setEmailValue] = (0,external_react_.useState)("");
    const [messageValue, setMessageValue] = (0,external_react_.useState)("");
    const handleIdealTourDurationChange = (e)=>{
        setIdealTourDurationValue(e.target.value);
    };
    const handleYourBudgetChange = (e)=>{
        setYourBudgetValue(e.target.value);
    };
    const handlePhoneNumberChange = (e)=>{
        setPhoneNumberValue(e.target.value);
    };
    const handleEmailChange = (e)=>{
        setEmailValue(e.target.value);
    };
    const handleMessageChange = (e)=>{
        setMessageValue(e.target.value);
    };
    const [popUpVisible, setPopUpVisible] = (0,external_react_.useState)(false);
    const showPopUp = (e)=>{
        setPopUpVisible((prevState)=>!prevState);
        setTimeout(()=>{
            setPopUpVisible((prevState)=>!prevState);
        }, 2000);
        setTimeout(()=>{
            setIdealTourDurationValue("");
            setYourBudgetValue("");
            setPhoneNumberValue("");
            setEmailValue("");
            setMessageValue("");
        }, 200);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "contact",
        className: "w-container mx-auto grid -xl:gap-16 grid-rows-1 xl:grid-cols-contact",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: assets/* heroPrivate */.IN,
                alt: "hero image",
                className: "m-auto"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                name: "frame",
                className: "hidden"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                className: "mx-auto flex flex-col gap-6 shadow-card-bold rounded-[30px] px-4 md:px-8 xl:px-[3.75rem] py-7",
                action: "https://formsubmit.co/8015104ab30fce20360f57b9f6f6ee16",
                method: "POST",
                target: "frame",
                onSubmit: (e)=>showPopUp(e),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-3 flex-col text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-neutral-900 font-semibold text-2xl md:text-[2rem] md:leading-10 ",
                                children: t("bookCustomTour")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-neutral-700 font-normal text-xs ",
                                children: t("customTourFormHeading2")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-7 -md:flex-col",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "",
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("phoneNumber")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        name: "Phone Number",
                                        placeholder: `${t("phoneNumberPlaceholder")}`,
                                        value: phoneNumberValue,
                                        onChange: (e)=>handlePhoneNumberChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "",
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("email")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "email",
                                        name: "Email",
                                        placeholder: `${t("emailPlaceholder")}`,
                                        required: true,
                                        value: emailValue,
                                        onChange: (e)=>handleEmailChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-2 flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-neutral-600 font-normal text-xs",
                                children: t("customTourFormNote")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "message",
                                className: "text-neutral-800 font-medium text-base",
                                children: t("message")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                id: "message",
                                name: "Message",
                                placeholder: `${t("messagePlaceholder")}`,
                                rows: 4,
                                value: messageValue,
                                onChange: (e)=>handleMessageChange(e),
                                className: "w-full px-6 py-3 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-7 -md:flex-col",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "",
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("idealTourDuration")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        name: "Phone Number",
                                        placeholder: `${t("idealTourDurationPlaceholder")}`,
                                        value: idealTourDurationValue,
                                        onChange: (e)=>handleIdealTourDurationChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "",
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("yourBudget")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "email",
                                        name: "Email",
                                        placeholder: `${t("yourBudgetPlaceholder")}`,
                                        required: true,
                                        value: yourBudgetValue,
                                        onChange: (e)=>handleYourBudgetChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "submit",
                        value: `${t("send")}`,
                        className: "bg-primary-extra-light hover:bg-primary-light w-fit cursor-pointer text-neutral-900    font-medium text-xl px-12 py-2.5 rounded-[1.125rem] mx-auto"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "hidden",
                        name: "_captcha",
                        value: "false"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "hidden",
                        name: "_cc",
                        value: "khanhduycb1510@gmail.com,kristalz248@gmail.com,kristalz931@gmail.com"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `fixed right-1/2 translate-x-1/2 px-8 py-4 rounded-2xl z-30
                bg-white dark:bg-semi-black transition-all duration-300 pointer-events-none 
                    ${popUpVisible ? "bottom-12 opacity-100" : "opacity-0 bottom-0"} shadow-card-bold`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-neutral-800 font-semibold text-base leading-none z-30",
                    children: "Your Message is sent. Thanks For contacting with us!"
                })
            })
        ]
    });
};
/* harmony default export */ const main_CustomTours = (CustomTours);

;// CONCATENATED MODULE: ./components/cards/ThemeCard.tsx


const ThemeCard = ({ image , title  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative z-20 flex justify-center items-center bg-neutral-800 px-6 md:px-12 py-5 md:py-10 rounded-[1.125rem] overflow-hidden   before:absolute before:top-0 before:left-0 before:z-10 before:bg-filter-dark before:w-full before:h-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "relative z-20 text-white font-semibold text-sm md:text-xl",
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: image,
                alt: "theme background",
                className: "absolute z-0 top-0 left-0 w-full h-full"
            })
        ]
    });
};
/* harmony default export */ const cards_ThemeCard = (ThemeCard);

;// CONCATENATED MODULE: ./components/main/ThemeTours.tsx



const themes = [
    "Romantic",
    "Honeymoon",
    "Relax",
    "Relax Luxury",
    "Hiking",
    "Bike Riding"
];
const ThemeTour = ({ t  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex gap-10 flex-col items-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-neutral-900 font-semibold text-2xl md:text-[2rem] -md:text-center",
                children: t("themeTourHeading")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex gap-6 flex-wrap items-center justify-center w-4/5",
                children: themes?.map((theme)=>/*#__PURE__*/ jsx_runtime_.jsx(cards_ThemeCard, {
                        image: assets/* themeImage1 */.w5,
                        title: theme
                    }, theme))
            })
        ]
    });
};
/* harmony default export */ const ThemeTours = (ThemeTour);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/main/ContactBanner.tsx





const ContactBanner = ({ t  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex -md:flex-col -md:items-center justify-between bg-primary-extra-light rounded-[30px] px-8 md:px-20 py-8",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-center items-center flex-col",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-neutral-900 font-semibold text-4xl mb-3 -md:text-center",
                        children: "CONTACT WITH US"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-neutral-800 font-normal text-xl mb-6 -md:text-center",
                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-8 -md:flex-col items-center mb-6",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-4 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: assets/* phoneIcon */.T0,
                                        alt: "phone icon"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex  flex-col",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-neutral-800 font-xs text-base",
                                                children: "ENG: 0379748073"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-neutral-800 font-normal text-base",
                                                children: "VN: 0985080324"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-4 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: assets/* mailIcon */.Zw,
                                        alt: "phone icon"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "text-neutral-800 font-normal text-base",
                                        children: "admin@joya.com.vn"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-6 items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://www.facebook.com/JOYA.TravelAgency",
                                target: "_blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: assets/* facebookIcon */.pj,
                                    alt: "facebook logo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://www.instagram.com/joya.travelagency/",
                                target: "_blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: assets/* instagramIcon */.tw,
                                    alt: "instagram logo"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: assets/* heroPrivate */.IN,
                alt: ""
            })
        ]
    });
};
/* harmony default export */ const main_ContactBanner = (ContactBanner);

;// CONCATENATED MODULE: ./pages/index.tsx













function Home() {
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (target_path_pages_index_tsx_import_Plus_Jakarta_Sans_arguments_weight_400_500_600_subsets_latin_vietnamese_variableName_plusJakartaSans_default()).className,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                    t: t
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                    className: "w-container mx-auto flex gap-8 md:gap-12 xl:gap-16 flex-col mb-8 relative mt-12",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(main_Banner, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(main_Categories, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Grandtours/* default */.Z, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(DayTours/* default */.Z, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ThemeTours, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(main_CustomTours, {
                            t: t
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(main_ContactBanner, {
                            t: t
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
            ]
        })
    });
}
async function getStaticProps({ locale  }) {
    return {
        props: {
            ...await (0,serverSideTranslations_.serverSideTranslations)(locale, [
                "common"
            ])
        }
    };
}


/***/ }),

/***/ 6337:
/***/ ((module) => {

"use strict";
module.exports = require("@grpc/grpc-js");

/***/ }),

/***/ 5831:
/***/ ((module) => {

"use strict";
module.exports = require("@grpc/proto-loader");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 3837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,954,647,415,670,599], () => (__webpack_exec__(9025)));
module.exports = __webpack_exports__;

})();