"use strict";
exports.id = 415;
exports.ids = [415];
exports.modules = {

/***/ 932:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_assets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2993);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
"use client";





const Footer = ()=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-primary-dark",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-container mx-auto py-12 xl:py-20 text-neutral-100 grid grid-footer xl:grid-cols-footer    -xl:gap-8 -xl:flex-col -xl:items-center -xl:text-center border-b border-neutral-800",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "/",
                                className: "mb-4 -xl:mx-auto w-fit",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .logoDark */ .wp,
                                    alt: "brand logo",
                                    className: "w-[6rem] aspect-square"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "font-semibold text-xs mb-8",
                                children: "JOYA JOINT STOCK COMPANY"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-6 [&>a>svg>path]:fill-neutral-100 -xl:mx-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "https://www.facebook.com/JOYA.TravelAgency",
                                        target: "_blank",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            width: "36",
                                            height: "36",
                                            viewBox: "0 0 36 36",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M36 18.0451C36 8.08421 27.936 0 18 0C8.064 0 0 8.08421 0 18.0451C0 26.7789 6.192 34.0511 14.4 35.7293V23.4586H10.8V18.0451H14.4V13.5338C14.4 10.0511 17.226 7.21804 20.7 7.21804H25.2V12.6316H21.6C20.61 12.6316 19.8 13.4436 19.8 14.4361V18.0451H25.2V23.4586H19.8V36C28.89 35.0977 36 27.4105 36 18.0451Z",
                                                fill: "#484747"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "https://www.instagram.com/joya.travelagency/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            width: "36",
                                            height: "36",
                                            viewBox: "0 0 36 36",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M10.44 0H25.56C31.32 0 36 4.68 36 10.44V25.56C36 28.3289 34.9001 30.9843 32.9422 32.9422C30.9843 34.9001 28.3289 36 25.56 36H10.44C4.68 36 0 31.32 0 25.56V10.44C0 7.67114 1.09993 5.01569 3.05781 3.05781C5.01569 1.09993 7.67114 0 10.44 0ZM10.08 3.6C8.3614 3.6 6.71318 4.28271 5.49795 5.49795C4.28271 6.71318 3.6 8.3614 3.6 10.08V25.92C3.6 29.502 6.498 32.4 10.08 32.4H25.92C27.6386 32.4 29.2868 31.7173 30.5021 30.5021C31.7173 29.2868 32.4 27.6386 32.4 25.92V10.08C32.4 6.498 29.502 3.6 25.92 3.6H10.08ZM27.45 6.3C28.0467 6.3 28.619 6.53705 29.041 6.95901C29.4629 7.38097 29.7 7.95326 29.7 8.55C29.7 9.14674 29.4629 9.71903 29.041 10.141C28.619 10.5629 28.0467 10.8 27.45 10.8C26.8533 10.8 26.281 10.5629 25.859 10.141C25.437 9.71903 25.2 9.14674 25.2 8.55C25.2 7.95326 25.437 7.38097 25.859 6.95901C26.281 6.53705 26.8533 6.3 27.45 6.3ZM18 9C20.3869 9 22.6761 9.94821 24.364 11.636C26.0518 13.3239 27 15.6131 27 18C27 20.3869 26.0518 22.6761 24.364 24.364C22.6761 26.0518 20.3869 27 18 27C15.6131 27 13.3239 26.0518 11.636 24.364C9.94821 22.6761 9 20.3869 9 18C9 15.6131 9.94821 13.3239 11.636 11.636C13.3239 9.94821 15.6131 9 18 9ZM18 12.6C16.5678 12.6 15.1943 13.1689 14.1816 14.1816C13.1689 15.1943 12.6 16.5678 12.6 18C12.6 19.4322 13.1689 20.8057 14.1816 21.8184C15.1943 22.8311 16.5678 23.4 18 23.4C19.4322 23.4 20.8057 22.8311 21.8184 21.8184C22.8311 20.8057 23.4 19.4322 23.4 18C23.4 16.5678 22.8311 15.1943 21.8184 14.1816C20.8057 13.1689 19.4322 12.6 18 12.6Z",
                                                fill: "#484747"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid -md:gap-8 grid-rows-1 md:grid-cols-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-4 flex-col md:justify-between",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                        className: "font-medium text-base",
                                        children: [
                                            t("address"),
                                            ": \xa0 ",
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "font-normal text-neutral-200",
                                                children: [
                                                    " ",
                                                    t("addressDetails")
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-2 -xl:mx-auto",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                className: "font-semibold text-base",
                                                children: [
                                                    t("phoneNumber"),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "font-normal text-base text-neutral-200",
                                                        children: "ENG: 0379748073"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "font-normal text-base text-neutral-200",
                                                        children: "VN: 0985080324"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                        className: "font-semibold text-base",
                                        children: [
                                            "Email: ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-normal text-neutral-200",
                                                children: "admin@joya.com.vn"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-4 flex-col xl:ml-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "font-semibold text-lg",
                                        children: t("links")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "flex -xl:gap-3 flex-col xl:justify-between h-full text-neutral-200",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/",
                                                    className: "font-medium text-base hover:text-neutral-100",
                                                    children: t("home")
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "#about",
                                                    className: "font-medium text-base hover:text-neutral-100",
                                                    children: t("about")
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "#tours",
                                                    className: "font-medium text-base hover:text-neutral-100",
                                                    children: t("tours")
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "#contact",
                                                    className: "font-medium text-base hover:text-neutral-100",
                                                    children: t("contact")
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/assets/JOYA_Catalogue_EN.pdf",
                                                    target: "_blank",
                                                    className: "font-medium text-base hover:text-neutral-100",
                                                    children: t("downloadCatalogue")
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-container mx-auto text-center py-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-neutral-300",
                    children: "JOYA \xa9 2023 All Rights Reserved."
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 9852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_assets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2993);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9332);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
"use client";

// @ts-nocheck






// run function when clicking outside of ref
const useClickDetector = (ref, func)=>{
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (ref.current && !ref.current.contains(event.target)) {
                func();
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        ref
    ]);
};
const lngs = new Map();
lngs.set("en", {
    nativeLanguage: "English"
});
lngs.set("vi", {
    nativeLanguage: "Tiếng Việt"
});
const Header = ({ t  })=>{
    const [lngDropdownOpened, setLngDropdownOpened] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const dropdownRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const hideDropdown = ()=>{
        setLngDropdownOpened(false);
    };
    useClickDetector(dropdownRef, hideDropdown);
    const [sidenavOpened, setSidenavOpened] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const changeLanguage = (lng)=>{
        next_i18next__WEBPACK_IMPORTED_MODULE_6__.i18n?.changeLanguage(lng);
        setLngDropdownOpened(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: "relative -xl:sticky top-0 left-0 z-30",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                className: "bg-white flex justify-between items-center w-header    mx-auto py-4 xl:py-6 -xl:px-4 relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .logoLight */ .QH,
                            alt: "",
                            className: "w-12 md:w-16 aspect-square"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "hidden xl:flex gap-[5.25rem]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "navlink-underline inline-block relative",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    href: "/",
                                    className: "text-neutral-800 font-medium text-base leading-5 [&:last-child]:mr-0",
                                    children: t("home")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "navlink-underline inline-block relative",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    href: "/about",
                                    className: "text-neutral-800 font-medium text-base leading-5",
                                    children: t("about")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "navlink-underline inline-block relative",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    href: "/tours",
                                    className: "text-neutral-800 font-medium text-base leading-5",
                                    children: t("tours")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "navlink-underline inline-block relative",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    href: "/contact",
                                    className: "text-neutral-800 font-medium text-base leading-5",
                                    children: t("contact")
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-8 items-center -xl:ml-auto",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: "/assets/JOYA_Catalogue_EN.pdf",
                                target: "_blank",
                                className: "hidden xl:block bg-primary-regular hover:bg-primary-dark px-6 py-4 rounded-[30px] text-neutral-100    font-semibold text-base leading-5",
                                children: t("downloadCatalogue")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-4 items-center cursor-pointer [&:hover>svg>path]:fill-primary-dark",
                                        onClick: ()=>setLngDropdownOpened((prevState)=>!prevState),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-neutral-800 font-medium text-base leading-5",
                                                children: next_i18next__WEBPACK_IMPORTED_MODULE_6__.i18n?.language.toUpperCase()
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                width: "24",
                                                height: "24",
                                                viewBox: "0 0 24 24",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    d: "M12 21.63C11.34 21.63 10.7748 21.39 10.3044 20.91C9.834 20.43 9.5992 19.86 9.6 19.2C9.6 18.54 9.8352 17.9748 10.3056 17.5044C10.776 17.034 11.3408 16.7992 12 16.8L12.72 16.11C12.88 15.95 13.0652 15.8248 13.2756 15.7344C13.486 15.644 13.7008 15.5992 13.92 15.6C14.38 15.6 14.7752 15.77 15.1056 16.11C15.436 16.45 15.6008 16.85 15.6 17.31V17.82C15.6 18.22 15.73 18.55 15.99 18.81C16.25 19.07 16.58 19.2 16.98 19.2C17.28 19.2 17.55 19.11 17.79 18.93C18.03 18.75 18.2 18.52 18.3 18.24L18.66 17.25C18.84 16.77 19.13 16.3748 19.53 16.0644C19.93 15.754 20.39 15.5992 20.91 15.6C21.13 15.04 21.3052 14.46 21.4356 13.86C21.566 13.26 21.6308 12.64 21.63 12C21.63 10.22 21.1852 8.5948 20.2956 7.1244C19.406 5.654 18.2408 4.4992 16.8 3.66V4.8C16.8 5.46 16.5648 6.0252 16.0944 6.4956C15.624 6.966 15.0592 7.2008 14.4 7.2H13.2V9.6C13.2 9.94 13.0848 10.2252 12.8544 10.4556C12.624 10.686 12.3392 10.8008 12 10.8H10.8V12.84C10.8 13.28 10.65 13.65 10.35 13.95C10.05 14.25 9.68 14.4 9.24 14.4C8.96 14.4 8.7048 14.34 8.4744 14.22C8.244 14.1 8.0592 13.93 7.92 13.71L6 10.8H4.8V12C4.8 12.62 4.59 13.15 4.17 13.59C3.75 14.03 3.25 14.29 2.67 14.37C3.19 16.45 4.3152 18.18 6.0456 19.56C7.776 20.94 9.7608 21.63 12 21.63ZM14.4 14.4C14.06 14.4 13.7748 14.2852 13.5444 14.0556C13.314 13.826 13.1992 13.5408 13.2 13.2C13.2 12.86 13.3152 12.5748 13.5456 12.3444C13.776 12.114 14.0608 11.9992 14.4 12H15.6C15.94 12 16.2252 12.1152 16.4556 12.3456C16.686 12.576 16.8008 12.8608 16.8 13.2C16.8 13.54 16.6848 13.8252 16.4544 14.0556C16.224 14.286 15.9392 14.4008 15.6 14.4H14.4ZM17.19 10.8C16.79 10.8 16.4748 10.6452 16.2444 10.3356C16.014 10.026 15.9592 9.6808 16.08 9.3L16.53 7.98C16.61 7.74 16.75 7.55 16.95 7.41C17.15 7.27 17.37 7.2 17.61 7.2C18.01 7.2 18.3252 7.3552 18.5556 7.6656C18.786 7.976 18.8408 8.3208 18.72 8.7L18.27 10.02C18.19 10.26 18.05 10.45 17.85 10.59C17.65 10.73 17.43 10.8 17.19 10.8ZM12 24C10.34 24 8.78 23.6848 7.32 23.0544C5.86 22.424 4.59 21.5692 3.51 20.49C2.43 19.41 1.5752 18.14 0.9456 16.68C0.316 15.22 0.0008 13.66 0 12C0 10.34 0.3152 8.78 0.9456 7.32C1.576 5.86 2.4308 4.59 3.51 3.51C4.59 2.43 5.86 1.5752 7.32 0.9456C8.78 0.316 10.34 0.0008 12 0C13.66 0 15.22 0.3152 16.68 0.9456C18.14 1.576 19.41 2.4308 20.49 3.51C21.57 4.59 22.4252 5.86 23.0556 7.32C23.686 8.78 24.0008 10.34 24 12C24 13.66 23.6848 15.22 23.0544 16.68C22.424 18.14 21.5692 19.41 20.49 20.49C19.41 21.57 18.14 22.4252 16.68 23.0556C15.22 23.686 13.66 24.0008 12 24Z",
                                                    fill: "#484747"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `flex-col ${lngDropdownOpened ? "flex" : "hidden"} gap-2 absolute z-20 bg-white shadow-card-bold rounded-xl
                bottom-0 right-1/2 translate-y-[110%] translate-x-1/2 w-fit p-2`,
                                        ref: dropdownRef,
                                        children: Object.keys(lngs).map((lng)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "submit",
                                                onClick: ()=>changeLanguage(lng),
                                                disabled: next_i18next__WEBPACK_IMPORTED_MODULE_6__.i18n?.resolvedLanguage === lng,
                                                className: `w-[8rem] font-medium ${next_i18next__WEBPACK_IMPORTED_MODULE_6__.i18n?.language === lng ? "text-neutral-700" : "text-neutral-600"} hover:text-neutral-700`,
                                                children: lngs.get(lng).nativeLanguage
                                            }, lng))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setSidenavOpened(true),
                                className: "xl:hidden",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .menuIcon */ .FO,
                                    alt: "menu icon",
                                    className: "w-6 aspect-square"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: ()=>setSidenavOpened(false),
                className: `${sidenavOpened ? "fixed" : "hidden"} xl:hidden top-8 md:top-12 right-4 z-30`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .closeIcon */ .UF,
                    alt: "close icon",
                    className: "md:w-6 aspect-square"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `w-sidenav h-screen min-h-full shadow-card-bold fixed right-0 top-0 bg-white z-20 
          ${sidenavOpened ? "translate-x-0" : "translate-x-[100%]"} transition-all duration-300
          flex gap-[1.875rem] flex-col items-center py-[3.75rem] mx-auto xl:hidden`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .logoLight */ .QH,
                            alt: "",
                            className: "w-20 aspect-square"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                        className: "flex gap-6 flex-col",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: "/",
                                className: "text-neutral-800 font-medium text-base leading-5 flex gap-2.5",
                                onClick: ()=>setSidenavOpened(false),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .homeIcon */ .WR,
                                        alt: "home icon"
                                    }),
                                    t("home")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: "/about",
                                className: "text-neutral-800 font-medium text-base leading-5 flex gap-2.5",
                                onClick: ()=>setSidenavOpened(false),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .aboutIcon */ .TR,
                                        alt: "about icon"
                                    }),
                                    t("about")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: "/tours",
                                className: "text-neutral-800 font-medium text-base leading-5 flex gap-2.5",
                                onClick: ()=>setSidenavOpened(false),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .planeIcon */ .D8,
                                        alt: "airplane icon"
                                    }),
                                    t("tours")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: "/contact",
                                className: "text-neutral-800 font-medium text-base leading-5 flex gap-2.5 ",
                                onClick: ()=>setSidenavOpened(false),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .phoneIcon */ .T0,
                                        alt: "phone icon",
                                        className: "w-[1.125rem] aspect-square"
                                    }),
                                    t("contact")
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: "/assets/JOYA_Catalogue_EN.pdf",
                        target: "_blank",
                        className: "bg-primary-dark px-6 py-4 rounded-[30px] text-neutral-100 font-semibold text-base leading-5",
                        children: t("downloadCatalogue")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);


/***/ }),

/***/ 2993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "TR": () => (/* reexport */ about),
  "nj": () => (/* reexport */ arrow_right),
  "K_": () => (/* reexport */ banner),
  "Bn": () => (/* reexport */ halongbay_small),
  "wT": () => (/* reexport */ trangan_small),
  "M1": () => (/* reexport */ themetour_small),
  "E8": () => (/* reexport */ bridge_small),
  "eQ": () => (/* reexport */ check_1),
  "aY": () => (/* reexport */ clock),
  "UF": () => (/* reexport */ assets_close),
  "pj": () => (/* reexport */ facebook),
  "ZB": () => (/* reexport */ gallery_image_1),
  "Br": () => (/* reexport */ gallery_image_2),
  "oO": () => (/* reexport */ gallery_image_3),
  "Dv": () => (/* reexport */ gallery_image_4),
  "z": () => (/* reexport */ gallery_image_5),
  "ST": () => (/* reexport */ gallery_image_6),
  "IN": () => (/* reexport */ hero_private),
  "gX": () => (/* reexport */ holding_hands_1),
  "WR": () => (/* reexport */ home),
  "tw": () => (/* reexport */ instagram),
  "pk": () => (/* reexport */ assets_location),
  "wp": () => (/* reexport */ logo_dark),
  "QH": () => (/* reexport */ logo_light),
  "ch": () => (/* reexport */ logo_light_large),
  "Zw": () => (/* reexport */ mail),
  "FO": () => (/* reexport */ menu),
  "T0": () => (/* reexport */ phone),
  "D8": () => (/* reexport */ plane),
  "w5": () => (/* reexport */ theme_image_1),
  "ZW": () => (/* reexport */ victory_fingers_1)
});

// UNUSED EXPORTS: tourPreview1

;// CONCATENATED MODULE: ./public/assets/holding-hands 1.svg
/* harmony default export */ const holding_hands_1 = ({"src":"/_next/static/media/holding-hands 1.e65b5a77.svg","height":50,"width":50,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/victory-fingers 1.svg
/* harmony default export */ const victory_fingers_1 = ({"src":"/_next/static/media/victory-fingers 1.071cada7.svg","height":50,"width":51,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/check 1.svg
/* harmony default export */ const check_1 = ({"src":"/_next/static/media/check 1.a97eb0db.svg","height":50,"width":51,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/phone.svg
/* harmony default export */ const phone = ({"src":"/_next/static/media/phone.64c109a6.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/mail.svg
/* harmony default export */ const mail = ({"src":"/_next/static/media/mail.bf7167ef.svg","height":26,"width":32,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/location.svg
/* harmony default export */ const assets_location = ({"src":"/_next/static/media/location.3d5392d5.svg","height":34,"width":30,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/facebook.svg
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.c1e488b9.svg","height":36,"width":36,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/instagram.svg
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.b3f64c14.svg","height":36,"width":36,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/logo_light_large.png
/* harmony default export */ const logo_light_large = ({"src":"/_next/static/media/logo_light_large.3d1b332d.png","height":120,"width":120,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5ElEQVR42mOAAYekLEn1qExpEPvIuhIREI2QTM7Ssk3MSrVOyExwSs4y3rG0WPzM5lKVrvZ8JrCCqNxsAaBkN1BRqV1iVrxqVOamipqckHsHyhXAChIKspUs4zMviEdmgRROt0nIfGGTmNV5cVupEcOpzZXMRVV5XLEFecIvTtaxABXa2iZmBtsm5cjsX1XkwrBqbgnznlXVzNd3V/AcXFNi8vhotdT/Z52cpzYWaxxcXWzNAAJHN1Qy719VKgVUILpjWbHI3hVF5gdWFfnvX13CyAADQElOoA51ILY4uLrIECYOAHzHWOZBB8v+AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/banner.jpg
/* harmony default export */ const banner = ({"src":"/_next/static/media/banner.b6a299c3.jpg","height":480,"width":1200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAMACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAAAgEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAIDQ/wD/xAAaEAACAgMAAAAAAAAAAAAAAAABAwACITLB/9oACAEBAAE/AHNYTm525P/EABURAQEAAAAAAAAAAAAAAAAAAAEA/9oACAECAQE/ABb/xAAXEQADAQAAAAAAAAAAAAAAAAAAA0Jx/9oACAEDAQE/AGTh/9k=","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/assets/gallery-image 1.jpg
/* harmony default export */ const gallery_image_1 = ({"src":"/_next/static/media/gallery-image 1.546f9d32.jpg","height":192,"width":282,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAoDV//8QAGxAAAgEFAAAAAAAAAAAAAAAAAQMAAgUTIqH/2gAIAQEAAT8At2VaEANOrKeCf//EABgRAQADAQAAAAAAAAAAAAAAAAEAAxEx/9oACAECAQE/ALtExeT/xAAYEQACAwAAAAAAAAAAAAAAAAAAAQMhMv/aAAgBAwEBPwCDLpH/2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/gallery-image 2.jpg
/* harmony default export */ const gallery_image_2 = ({"src":"/_next/static/media/gallery-image 2.9355b67a.jpg","height":192,"width":282,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAALolL//EAB4QAAIBAwUAAAAAAAAAAAAAAAECAwAEBRITISJh/9oACAEBAAE/ALTbyeMSa6iVys7dedBPor//xAAcEQABAwUAAAAAAAAAAAAAAAABAwQSAAIREyH/2gAIAQIBAT8AeOV0tML8STBPK//EABkRAAMAAwAAAAAAAAAAAAAAAAEDEgATMf/aAAgBAwEBPwDUu2ieMIGf/9k=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/gallery-image 3.jpg
/* harmony default export */ const gallery_image_3 = ({"src":"/_next/static/media/gallery-image 3.ffed0607.jpg","height":192,"width":282,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAKUTv//EABwQAAICAgMAAAAAAAAAAAAAAAECAwQAERIiYf/aAAgBAQABPwCSrPXpMIL00RZu7LrkdesDn//EABcRAAMBAAAAAAAAAAAAAAAAAAABESH/2gAIAQIBAT8ArWVn/8QAGBEAAgMAAAAAAAAAAAAAAAAAAAERQZH/2gAIAQMBAT8AbuFh/9k=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/gallery-image 4.jpg
/* harmony default export */ const gallery_image_4 = ({"src":"/_next/static/media/gallery-image 4.29bd0659.jpg","height":192,"width":282,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAJwCj//EABsQAQACAgMAAAAAAAAAAAAAAAIBAwQSAAUh/9oACAEBAAE/AD3mecU0G+0wXoVt7HP/xAAXEQADAQAAAAAAAAAAAAAAAAAAAhJR/9oACAECAQE/AKbT/8QAGBEAAgMAAAAAAAAAAAAAAAAAAAECE0H/2gAIAQMBAT8Aqg8P/9k=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/gallery-image 5.jpg
/* harmony default export */ const gallery_image_5 = ({"src":"/_next/static/media/gallery-image 5.71136387.jpg","height":192,"width":282,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAAAwEBAQAAAAAAAAAAAAAAAAAAAgT/2gAMAwEAAhADEAAAAJgVf//EABsQAAICAwEAAAAAAAAAAAAAAAECAwQABRKx/9oACAEBAAE/AJNlaGrpVGnmZZa5LHrnwZ//xAAXEQEBAQEAAAAAAAAAAAAAAAACAQAR/9oACAECAQE/AElFeXf/xAAYEQADAQEAAAAAAAAAAAAAAAABAgMAEf/aAAgBAwEBPwCUpvGZZQTzf//Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/gallery-image 6.jpg
/* harmony default export */ const gallery_image_6 = ({"src":"/_next/static/media/gallery-image 6.92d93c7f.jpg","height":192,"width":282,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAAAQP/2gAMAwEAAhADEAAAAKgV/8QAHRAAAQIHAAAAAAAAAAAAAAAAAwABAgQFERMjUf/aAAgBAQABPwAVfmMUOkduMv/EABkRAAEFAAAAAAAAAAAAAAAAAAEAAhEykf/aAAgBAgEBPwBxM2Or/8QAGREBAAIDAAAAAAAAAAAAAAAAAgABEiKS/9oACAEDAQE/AARjWh5qf//Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/logo_dark.png
/* harmony default export */ const logo_dark = ({"src":"/_next/static/media/logo_dark.e20821de.png","height":572,"width":599,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/ElEQVR42mMAgZYJ04U7p86Obp04wxjE//X7t/znr18FwZIzFq1g6po626598sy4jimzyoF0RPOEaaqv3741/PnrlxhY0YRZC2Q7p8ze2jF5VkLnlFkhQEW3e6bPLf7//78+WEH/rPluQN3ngUzG7mlzlgPxg4aeyYtevXnrwnDz3gOWiXMWcbdPniUKUtzQO8UKaFKKhE+c/Jt37z0YTp2/yA6S+Pzli9DzV6+sgcbKvX7/XgxIc/74+TMQbMWZS1c4rt++I/70xUuBHfsP8d64c1fq67dvUd9//FABK+ibv5zxzbt30p++fDH8+u27zY8fP0OAkuoMDAwMAJK2g9ZtTucxAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/logo_light.png
/* harmony default export */ const logo_light = ({"src":"/_next/static/media/logo_light.13760381.png","height":80,"width":80,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA6UlEQVR42mOAAYekLEn1qExpBiA4sq5UlAEZOCZladkkZqXaJGTFOyVnmWxfWix+ZnOpSm9XPhNYQVRutqB1Qma3bWJWqV1SVpxqVOamipqckHsHyhXAChIKspUs4zPPC0VkCQAVTrdJyHxhk5jZeXFbqRHD8Y2VzMXV+VyJhXnCj49WsQIV2tomZgbbJufI7F9V5MKwYk4J847VdUxXd5XzHFxdYvr4SJXU/xfdnKc2FqsfXFNszQBxdQXzvlWlUgfXlIjuXFYssndFkfmBVcX++9eWMTLAAFA358HVxepAbHlwdZEhTBwAePRY2uPvdGYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/menu.svg
/* harmony default export */ const menu = ({"src":"/_next/static/media/menu.fefeb86a.svg","height":22,"width":33,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/close.svg
/* harmony default export */ const assets_close = ({"src":"/_next/static/media/close.8cd3928a.svg","height":20,"width":20,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/home.svg
/* harmony default export */ const home = ({"src":"/_next/static/media/home.d6b6ea19.svg","height":17,"width":21,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/about.svg
/* harmony default export */ const about = ({"src":"/_next/static/media/about.9c6e502b.svg","height":20,"width":21,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/plane.svg
/* harmony default export */ const plane = ({"src":"/_next/static/media/plane.bd47f55d.svg","height":18,"width":18,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/clock.svg
/* harmony default export */ const clock = ({"src":"/_next/static/media/clock.da6abf6f.svg","height":11,"width":10,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/tour-preview-1.jpg
/* harmony default export */ const tour_preview_1 = ({"src":"/_next/static/media/tour-preview-1.fb6cedb7.jpg","height":192,"width":282,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAAAwEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAALgw/8QAHRAAAgIBBQAAAAAAAAAAAAAAAQMCBCEAFBUicv/aAAgBAQABPwDmrzab3bl4KxPAlHPXzr//xAAaEQACAgMAAAAAAAAAAAAAAAABAgADERJB/9oACAECAQE/ALWK64PJ/8QAGREAAQUAAAAAAAAAAAAAAAAAAAIREiFR/9oACAEDAQE/AE3J9P/Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/arrow-right.svg
/* harmony default export */ const arrow_right = ({"src":"/_next/static/media/arrow-right.0cd9001f.svg","height":20,"width":9,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/hero-private.png
/* harmony default export */ const hero_private = ({"src":"/_next/static/media/hero-private.a1fd9e40.png","height":256,"width":256,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5klEQVR42mMAgTPtqiw5QW2axV4V8gxIoGH6ZUYo8ypPXOCUQJeEdW4gXu/8KwYN0y8IwVV+2JRW/nFv863v6y1v/F3GYAMSK9LIZZvezsAIUbA25OKf7SH/367L/X9876mne0+9mHz/7BkxqP5J8o8WBD78vMn//95ph39cWHX5/75LH/6vPPBqNdyKr2ttzn7bGvd/x+Y7/9etefj3+N57/w8sunDv9Y7D3GAFD5ckpTxb5Hlp39YjVyesffHr+Yoj/9+tOfT/8+Jt5kie+sIOJPjKOo5q3pyx1+LD/B0mL1fs5QQAP4ty9U5a/UIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/theme-image-1.jpg
/* harmony default export */ const theme_image_1 = ({"src":"/_next/static/media/theme-image-1.fd528c55.jpg","height":123,"width":180,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAKQTv//EABwQAAICAgMAAAAAAAAAAAAAAAECAwQAERIigf/aAAgBAQABPwCSpPXpMIL00RZu7LrkfWBz/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAERIf/aAAgBAgEBPwCtZWf/xAAYEQACAwAAAAAAAAAAAAAAAAAAARFBkf/aAAgBAwEBPwBu4WH/2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/halongbay-small.jpg
/* harmony default export */ const halongbay_small = ({"src":"/_next/static/media/halongbay-small.ebe9572f.jpg","height":640,"width":960,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAAAwEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAALAw/8QAHhAAAgIABwAAAAAAAAAAAAAAAQIDBAARFBUhInL/2gAIAQEAAT8A3q/LSnm1M4KK3AZcj184/8QAGhEAAQUBAAAAAAAAAAAAAAAAAgABAxESUf/aAAgBAgEBPwCUnHNcX//EABkRAAEFAAAAAAAAAAAAAAAAAAACERIhUf/aAAgBAwEBPwBFyfT/2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/trangan-small.jpg
/* harmony default export */ const trangan_small = ({"src":"/_next/static/media/trangan-small.e4f09995.jpg","height":362,"width":645,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAkgB//8QAGxAAAgEFAAAAAAAAAAAAAAAAAQQDAAIFE0L/2gAIAQEAAT8AZyL2u5UsyGEcE1//xAAZEQEAAgMAAAAAAAAAAAAAAAABAAIRIUL/2gAIAQIBAT8AVxXfJP/EABcRAAMBAAAAAAAAAAAAAAAAAAACQXH/2gAIAQMBAT8AW6f/2Q==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/assets/themetour-small.jpg
/* harmony default export */ const themetour_small = ({"src":"/_next/static/media/themetour-small.89a31137.jpg","height":550,"width":825,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAuAZP/8QAHRAAAQQCAwAAAAAAAAAAAAAAAgEDBBEAMhIiMf/aAAgBAQABPwA50mdbQuEyHBV6bbV7n//EABgRAAIDAAAAAAAAAAAAAAAAAAABAgMh/9oACAECAQE/ALG4vD//xAAWEQEBAQAAAAAAAAAAAAAAAAABAAP/2gAIAQMBAT8AzBL/2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/bridge-small.jpg
/* harmony default export */ const bridge_small = ({"src":"/_next/static/media/bridge-small.3d0ab1d5.jpg","height":560,"width":448,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAALAz/8QAHBAAAgICAwAAAAAAAAAAAAAAAQMCBAARFiJh/9oACAEBAAE/AOWUVVk2GJiIM1oDtIH3P//EABcRAQADAAAAAAAAAAAAAAAAAAEAAkL/2gAIAQIBAT8AGzpn/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECQ//aAAgBAwEBPwBzCzk//9k=","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/index.ts



































/***/ })

};
;