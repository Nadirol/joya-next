"use strict";
exports.id = 670;
exports.ids = [670];
exports.modules = {

/***/ 2913:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_assets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2993);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



const MoveSliderButton = ({ direction , handleClick  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "p-3 shadow-button hover:shadow-button-semibold transition-shadow duration-300 rounded-[50%] aspect-square",
        onClick: handleClick,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
            src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .arrowRightIcon */ .nj,
            alt: "arrow right icon",
            className: `${direction === "prev" ? "rotate-180" : ""} w-3 aspect-square m-auto`
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MoveSliderButton);


/***/ }),

/***/ 441:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_assets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2993);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);




function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
const TourCard = ({ id , image , title , destinations , duration , price , t  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
        href: `/tours/${id}`,
        className: "rounded-2xl shadow-card hover:shadow-card-semibold min-w-[141px] md:min-w-[282px] snap-start overflow-hidden",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[141px] md:w-[282px] h-[98px] md:h-[192px] overflow-hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: image,
                    alt: "tour preview image",
                    width: 282,
                    height: 192,
                    className: "hover:scale-[1.1] transition-all duration-300 min-h-[192px]"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col justify-between h-[13rem] md:h-[11rem] px-2 py-4",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-2.5 flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-neutral-900 font-medium text-sm md:text-base",
                                children: title
                            }),
                            destinations && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .locationIcon */ .pk,
                                        alt: "location icon",
                                        className: "w-2 aspect-square"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "truncate text-neutral-700 font-normal text-xs",
                                        children: destinations
                                    })
                                ]
                            }),
                            duration && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .clockIcon */ .aY,
                                        alt: "clock icon"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: " text-neutral-700 font-normal text-xs",
                                        children: duration === 1 ? duration + " " + t("day") : duration + " " + t("days")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex -md:gap-4 justify-between -md:flex-col px-2",
                        children: [
                            price && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "text-neutral-900 font-medium text-xs md:text-base",
                                children: [
                                    numberWithCommas(price),
                                    " đ"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `text-neutral-900 font-medium text-xs md:text-base ${price ? "" : "ml-auto"}`,
                                children: "Book now"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TourCard);


/***/ }),

/***/ 2670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _buttons_MoveSliderButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2913);
/* harmony import */ var _cards_TourCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(441);
/* harmony import */ var _firebaseConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7309);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8847);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
// @ts-nocheck






const Grandtours = ({ t  })=>{
    const [tours, setTours] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const getTours = async ()=>{
        await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_4__/* .getDocs */ .PL)(_firebaseConfig__WEBPACK_IMPORTED_MODULE_3__/* .colRef */ .G).then((snapshot)=>{
            const newData = snapshot.docs.reverse().map((doc)=>({
                    ...doc.data(),
                    id: doc.id
                }));
            setTours(newData);
            console.log(tours, newData);
        }).catch((err)=>{
            console.log(err.message);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        getTours();
    }, []);
    const toursSliderRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const prevTour = ()=>toursSliderRef.current.scrollBy({
            top: 0,
            left: -1,
            behavior: "smooth"
        });
    const nextTour = ()=>{
        toursSliderRef.current.scrollBy({
            top: 0,
            left: 100,
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex gap-10 flex-col",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-neutral-900 font-semibold text-xl md:text-[1.75rem]",
                        children: t("grandTourHeading")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-2.5 items-center -md:hidden",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_buttons_MoveSliderButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                direction: "prev",
                                handleClick: prevTour
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_buttons_MoveSliderButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                direction: "next",
                                handleClick: nextTour
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex gap-8 md:gap-12 overflow-x-scroll scrollbar-hide snap-x snap-mandatory overscroll-x-contain overflow-y-visible pb-1",
                ref: toursSliderRef,
                children: tours?.filter((tour)=>tour.tourType === "grand").map((tour)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_TourCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        id: tour.id,
                        image: tour.image,
                        title: tour.title,
                        destinations: tour.destinations,
                        duration: tour.duration,
                        price: tour.price,
                        t: t
                    }, tour.id))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Grandtours);


/***/ }),

/***/ 7309:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ colRef),
/* harmony export */   "db": () => (/* binding */ db)
/* harmony export */ });
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9286);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8847);
// Import the functions you need from the SDKs you need


const firebaseConfig = {
    apiKey: "AIzaSyAwi61Rcye5wgsBqvZU8LR2jv9FEvXJsb4",
    authDomain: "joya-7cae6.firebaseapp.com",
    projectId: "joya-7cae6",
    storageBucket: "joya-7cae6.appspot.com",
    messagingSenderId: "143741114053",
    appId: "1:143741114053:web:2b872f2798211304c402ac",
    measurementId: "G-349HPWMESN"
};
// Initialize Firebase
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__/* .initializeApp */ .ZF)(firebaseConfig);
const db = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__/* .getFirestore */ .ad)();
const colRef = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__/* .collection */ .hJ)(db, "tours");
(0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__/* .getDocs */ .PL)(colRef).then((snapshot)=>{
    console.log(snapshot.docs);
});


/***/ })

};
;