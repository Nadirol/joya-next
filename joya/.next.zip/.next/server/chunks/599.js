"use strict";
exports.id = 599;
exports.ids = [599];
exports.modules = {

/***/ 3599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _buttons_MoveSliderButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2913);
/* harmony import */ var _cards_TourCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(441);
/* harmony import */ var _firebaseConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7309);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8847);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
// @ts-nocheck






const DayTours = ({ t  })=>{
    const [tours, setTours] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const getTours = async ()=>{
        await (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_4__/* .getDocs */ .PL)(_firebaseConfig__WEBPACK_IMPORTED_MODULE_3__/* .colRef */ .G).then((snapshot)=>{
            const newData = snapshot.docs.reverse().map((doc)=>({
                    ...doc.data(),
                    id: doc.id
                }));
            setTours(newData);
            console.log(tours, newData);
        }).catch((err)=>{
            console.log(err.message);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        getTours();
    }, []);
    const toursSliderRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const prevTour = ()=>toursSliderRef.current.scrollBy({
            top: 0,
            left: -10,
            behavior: "smooth"
        });
    const nextTour = ()=>{
        toursSliderRef.current.scrollBy({
            top: 0,
            left: 100,
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex gap-10 flex-col",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-neutral-900 font-semibold text-xl md:text-[1.75rem]",
                        children: t("dayTourHeading")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-2.5 items-center -md:hidden",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_buttons_MoveSliderButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                direction: "prev",
                                handleClick: prevTour
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_buttons_MoveSliderButton__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                direction: "next",
                                handleClick: nextTour
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex gap-8 md:gap-12 overflow-x-scroll scrollbar-hide snap-x snap-mandatory overscroll-x-contain overflow-y-visible pb-1",
                ref: toursSliderRef,
                children: tours?.filter((tour)=>tour.tourType === "day").map((tour)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_TourCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        id: tour.id,
                        image: tour.image,
                        title: tour.title,
                        destinations: tour.destinations,
                        duration: tour.duration,
                        price: tour.price,
                        t: t
                    }, tour.id))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DayTours);


/***/ })

};
;