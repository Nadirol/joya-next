"use strict";
exports.id = 11;
exports.ids = [11];
exports.modules = {

/***/ 6011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _public_assets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2993);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
"use client";

// @ts-nocheck




const Contact = ({ t  })=>{
    const [firstNameValue, setFirstNameValue] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [lastNameValue, setLastNameValue] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [phoneNumberValue, setPhoneNumberValue] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [emailValue, setEmailValue] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [messageValue, setMessageValue] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const handleFirstNameChange = (e)=>{
        setFirstNameValue(e.target.value);
    };
    const handleLastNameChange = (e)=>{
        setLastNameValue(e.target.value);
    };
    const handlePhoneNumberChange = (e)=>{
        setPhoneNumberValue(e.target.value);
    };
    const handleEmailChange = (e)=>{
        setEmailValue(e.target.value);
    };
    const handleMessageChange = (e)=>{
        setMessageValue(e.target.value);
    };
    const [popUpVisible, setPopUpVisible] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const showPopUp = (e)=>{
        setPopUpVisible((prevState)=>!prevState);
        setTimeout(()=>{
            setPopUpVisible((prevState)=>!prevState);
        }, 2000);
        setTimeout(()=>{
            setFirstNameValue("");
            setLastNameValue("");
            setPhoneNumberValue("");
            setEmailValue("");
            setMessageValue("");
        }, 200);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        id: "contact",
        className: "w-container mx-auto grid -xl:gap-16 grid-rows-1 xl:grid-cols-contact place-items-center    px-4 md:px-8 xl:px-[3.75rem] py-7 shadow-card-bold rounded-[30px]",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "h-full flex -xl:gap-6 flex-col justify-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .logoLightLarge */ .ch,
                        alt: "brand logo",
                        className: "w-[7.5rem] aspect-square mx-auto"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-6 flex-col -xl:items-center -xl:text-center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .phoneIcon */ .T0,
                                        alt: "phone icon"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex  flex-col",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-neutral-800 font-regular text-base xl:text-lg",
                                                children: "ENG: 0379748073"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-neutral-800 font-regular text-base xl:text-lg",
                                                children: "VN: 0985080324"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .mailIcon */ .Zw,
                                        alt: "phone icon"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-neutral-800 font-regular text-base xl:text-lg",
                                        children: "admin@joya.com.vn"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .locationIcon */ .pk,
                                        alt: "phone icon"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-neutral-800 font-regular text-base xl:text-lg",
                                        children: t("addressDetails")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-[1.125rem] flex-col text-center items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-neutral-900 font-medium text-2xl",
                                children: "Socials"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-6",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "https://www.facebook.com/JOYA.TravelAgency",
                                        target: "_blank",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .facebookIcon */ .pj,
                                            alt: "facebook logo"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "https://www.instagram.com/joya.travelagency/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            src: _public_assets__WEBPACK_IMPORTED_MODULE_1__/* .instagramIcon */ .tw,
                                            alt: "instagram logo"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                name: "frame",
                className: "hidden"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                className: "mx-auto flex flex-col gap-6",
                action: "https://formsubmit.co/8015104ab30fce20360f57b9f6f6ee16",
                method: "POST",
                target: "frame",
                onSubmit: (e)=>showPopUp(e),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-neutral-900 font-semibold text-2xl md:text-[2rem] md:leading-10 text-center",
                        children: t("sendAMessage")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-7 -md:flex-col w-full",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("firstName")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        name: "First Name",
                                        placeholder: `${t("firstNamePlaceholder")}`,
                                        required: true,
                                        value: firstNameValue,
                                        onChange: (e)=>handleFirstNameChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "",
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("lastName")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        name: "Last Name",
                                        placeholder: `${t("lastNamePlaceholder")}`,
                                        required: true,
                                        value: lastNameValue,
                                        onChange: (e)=>handleLastNameChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-7 -md:flex-col",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "",
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("phoneNumber")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        name: "Phone Number",
                                        placeholder: `${t("phoneNumberPlaceholder")}`,
                                        value: phoneNumberValue,
                                        onChange: (e)=>handlePhoneNumberChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2 flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "",
                                        className: "text-neutral-800 font-medium text-base",
                                        children: t("email")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "email",
                                        name: "Email",
                                        placeholder: `${t("emailPlaceholder")}`,
                                        required: true,
                                        value: emailValue,
                                        onChange: (e)=>handleEmailChange(e),
                                        className: "w-input-field px-6 py-2 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-2 flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "message",
                                className: "text-neutral-800 font-medium text-base",
                                children: t("message")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                id: "message",
                                name: "Message",
                                placeholder: `${t("messagePlaceholder")}`,
                                rows: 4,
                                value: messageValue,
                                onChange: (e)=>handleMessageChange(e),
                                className: "w-full px-6 py-3 border border-neutral-500 rounded-2xl placeholder:text-xs text-base"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "submit",
                        value: `${t("send")}`,
                        className: "bg-primary-extra-light hover:bg-primary-light w-fit cursor-pointer text-neutral-900    font-medium text-xl px-12 py-2.5 rounded-[1.125rem] mx-auto"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "hidden",
                        name: "_captcha",
                        value: "false"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "hidden",
                        name: "_cc",
                        value: "khanhduycb1510@gmail.com,kristalz248@gmail.com,kristalz931@gmail.com"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `fixed right-1/2 translate-x-1/2 px-8 py-4 rounded-2xl z-30
                bg-white dark:bg-semi-black transition-all duration-300 pointer-events-none 
                    ${popUpVisible ? "bottom-12 opacity-100" : "opacity-0 bottom-0"} shadow-card-bold`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "text-neutral-800 font-semibold text-base leading-none z-30",
                    children: "Your Message is sent. Thanks For contacting with us!"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact);


/***/ })

};
;